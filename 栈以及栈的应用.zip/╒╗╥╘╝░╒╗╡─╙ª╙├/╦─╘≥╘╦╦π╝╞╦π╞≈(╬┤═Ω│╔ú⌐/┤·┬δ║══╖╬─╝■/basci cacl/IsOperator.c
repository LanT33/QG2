
#include "IsOperator.h"

int tranf(SqStack* m,char *s)
{	m->elem=(ElemType *)malloc(sizeof(ElemType));
    int top=-1;
    char temp;
      //ջ�Ĵ�С������Ҫ���ģ����߿������ڴ���������
    while((temp=getchar())!='\n')
    {
        if(temp>='0'&&temp<='9')        //�������ֱ���ʽ����ĸ����ʽ��֧��С��
        {
        	s[++top]=temp;
		//m->elem[++i]=temp;
		//m->top++;
		printf("%c",s[top]);
        }

        else
        {	//m->elem[i]='#';
		//i++;
		//m->top++;
		s[++top]='#';
		//�ָ�����
            if(temp=='*'||temp=='/')
            {
                while(top>=0&&(s[top]=='*'||s[top]=='/'))        //��֤ջ����Խ��
                {
			s[++top]=m->elem[m->top--];
			printf("%c",s[top]);
                }

               m->elem[++m->top]=temp;
            }
            else if(temp=='+'||temp=='-')
            {
                while(m->elem[m->top]!='('&&m->top>=0)
		{
			s[++top]=m->elem[m->top--];
			printf("%c",s[top]);
                }
                m->elem[++m->top]=temp;
            }
            else if(temp=='(')//�ж�����
                m->elem[++m->top]=temp;
            else if(temp==')')
            {
                while(m->elem[m->top]!='(')
		{
			s[++top]=m->elem[m->top--];
			printf("%c",s[top]);
                }
                m->top--;
            }
        }
    }
    //printf("\nelem:");
    while(m->top>=0)
    {
    	s[++top]=m->elem[m->top--];
	printf("%c\n",s[top]);
	/*m->elem[++i]=s[top--];
	m->top++;
	printf("%c",m->elem[i]);*/
    }
 printf("�ɹ�ת��Ϊ��׺����ʽ\n");
    m->size =top+1;
   //printf("m->top:\n%d",m->top);
    return top;
}

void Calc(SqStack *m,char* s,int top)
{
	int i=0;
	int num=0;
	/*for(i=m->top;i>-1;i--)
	{
		s->elem[i]=m->elem[i];
	}
	*/
	//printf("top:%d\n",top);
	while(i<=top)
	{
		int j=1;
		int temp=0;
		if(s[i]>='0'&&s[i]<='9')
		{
			while(s[i]>='0'&&s[i]<='9')
			{
				//printf("s[]%c\n",s[i]);
				temp=temp*j+s[i]-'0';
				j=10;
				i++;
				//printf("%d\n",temp);
			}
			m->top++;
			m->elem[m->top]=temp;

		}
		//printf("temp:%d,%d\n",m->elem[m->top-1],m->elem[m->top]);
		if(!(s[i]>='0'&&s[i]<='9'))//m->elem[i++]>=48&&m->elem[i++]<=57
		{
			if(s[i]=='#')
			{
				//printf(" sdf");
				i++;
				continue;
			}
			//printf(" s\n");
			switch(s[i])
			{
			case'+':
				//printf("%d,%d\n",m->elem[m->top],m->elem[m->top-1]);
				num=m->elem[m->top]+m->elem[m->top-1];
				m->elem[--m->top]=num;
				//printf("%d\n",m->elem[m->top]);
				break;
			case'-':
				//printf("-\n");
				num=m->elem[m->top]-m->elem[m->top-1];
				m->elem[--m->top]=num;
				break;
			case'*':
				//printf("*\n");
				num=m->elem[m->top]*m->elem[m->top-1];
				m->elem[--m->top]=num;
				break;
			case'/':
				//printf("/\n");
				num=m->elem[m->top]/m->elem[m->top-1];
				m->elem[--m->top]=num;
				break;
			default:
				return ;
			}
		}
		printf("������ɣ�");
		i++;
	}
	printf("�����:\n\n%d\n\n",m->elem[m->top]);
	return ;
}


void printStack2(SqStack *s)//��ӡ
{
	for(int i=0;i<=s->top;i++)
	{
		printf("%c",s->elem[i]);
	}
	return ;
}

int Input()
{
	int num = 0;
	int status = 0;
	char str[100];
	do
	{
		scanf("%s", str);
		status = SUCCESS;
		int i;
		for (i=0;str[i]!='\0';i++)
		{

			if (i == 0)
			{
				if (str[i]=='-'||str[i]=='+')
					continue;
			}
			else
			{
				if (str[i] < '0' || str[i] > '9')
				{
					status = ERROR;
				}
			}
		}
		if (status == ERROR)
		{
			printf("��������������:");
		}
		else
		{
			 i = 0;
			for (i = 0, num = 0; str[i] != '\0'; i++)
			{
				if (i == 0)
				{
					if (str[i] == '-' || str[i] == '+')
					{
						continue;
					}
					else
					{
						num *= 10;
						num += (str[i] - 48);
					}
				}
				else
				{
					num *= 10;
					num += (str[i] - 48);
				}
			}
			if (str[0] == '-')
			{
				num = -num;
			}
			// Check if the number entered is out of bounds.
			if (i>=10)
			{
				printf("������Χ������������:");
				status = ERROR;
			}
		}
	} while (status == ERROR);
	return num;
}



/*int InputCacl(char *p)//������������
{
	int num = 0;
	int status = 0;
	char str[100]=p[100];
	do
	{
		scanf("%s", str);
		status = SUCCESS;
		int i;
		for (i=0;str[i]!='\0';i++)//�޳�����������
		{

			if (i == 0)
			{
				if (str[i]=='-'||str[i]=='+'||str[i]=='*'||str=='/')
					continue;
			}
			else
			{
				if (str[i] < '0' || str[i] > '9')
				{
					status = ERROR;
				}
			}
		}
		if (status == ERROR)
		{
			printf("��������������:");
		}
		else
		{
			 i = 0;
			for (i = 0, num = 0; str[i] != '\0'; i++)
			{
				if (i == 0)
				{
					if (str[i] == '-' || str[i] == '+')
					{
						continue;
					}
					else
					{
						num *= 10;
						num += (str[i] - 48);
					}
				}
				else
				{
					num *= 10;
					num += (str[i] - 48);
				}
			}
			if(str[0] == '-')
			{
				num = -num;
			}
			// Check if the number entered is out of bounds.
			if (i>=10)
			{
				printf("������Χ������������:");
				status = ERROR;
			}
		}
	}
	while (status == ERROR);
	return p;
}*/
