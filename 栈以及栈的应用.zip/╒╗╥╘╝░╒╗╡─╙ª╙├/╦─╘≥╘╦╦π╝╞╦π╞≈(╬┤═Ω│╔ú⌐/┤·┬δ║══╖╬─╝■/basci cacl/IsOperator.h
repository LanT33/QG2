#ifndef ISOPERATOR_H_INCLUDED
#define ISOPERATOR_H_INCLUDED

#endif // ISOPERATOR_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>


typedef enum Status
{
	ERROR = 0, SUCCESS = 1
} Status;

typedef int ElemType;

typedef struct SqStack
{
	ElemType *elem;
	int top;
	int size;
} SqStack;

int IsOperator(char ch);



int Precedence(char op);


int tranf(SqStack* m,char *s);

void printStack2(SqStack *s);
void Calc(SqStack *m,char* s,int top);
int Input();//��ֹ�������
