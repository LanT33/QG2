#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED



#endif // FUNCTION_H_INCLUDED

char *convert(char * s, int numRows);
int Input();
