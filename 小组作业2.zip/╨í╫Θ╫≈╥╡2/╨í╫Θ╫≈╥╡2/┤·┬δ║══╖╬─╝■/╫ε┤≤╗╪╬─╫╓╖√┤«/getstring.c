#include "getstring.h"

char* getstring(const char *str,int *m)
{
    bool dp[100][100];
    int i,j,len;
    int longest = 1;//��Ӵ��ĳ���
    int tmp;
    int n = strlen(str);
    char a[n];//��Ӵ����λ��
    for(i = 0; i < n; i++)
    {
        dp[i][i] = 1;
        if(str[i] == str[i + 1])
        {
            dp[i][i + 1] = 1;
            longest = 2;
            strncpy(a,str + i,2);
        }
    }
    for(len = 3; len <= n; len++)//�Ӵ�����
    {
        for(i = 0; i <= n - len; i++)//�Ӵ���ʼλ��
        {
            j = i + len - 1;
            if(str[i] == str[j])
            {
                dp[i][j] = dp[i + 1][j - 1];
                if(dp[i][j] == 1)
                {
                    tmp = j - i + 1;
                    if(longest < tmp)
                    {
                        longest = tmp;
                        strncpy(a,str + i,tmp);
                    }
                }
            }
            else
                dp[i][j] = 0;
        }
    }
    printf("�������Ӵ�����Ϊ%d\n",longest);

    if(longest == 1)
    {
    	printf("û�л����Ӵ�");
    	return NULL;
    }
    char *s = a;
    *m=longest;
    return s;
}




