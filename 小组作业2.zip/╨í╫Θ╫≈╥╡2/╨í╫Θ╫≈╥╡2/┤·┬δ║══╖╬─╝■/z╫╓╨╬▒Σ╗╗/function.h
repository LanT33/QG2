#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED



#endif // FUNCTION_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char *convert(char * s, int numRows);
int Input();
