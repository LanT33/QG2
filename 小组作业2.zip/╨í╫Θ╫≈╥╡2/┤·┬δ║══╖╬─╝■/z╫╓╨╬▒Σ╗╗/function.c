char *convert(char * s, int round)
{
	int n=strlen(s);
	int k = 0;
	if (round == 1)
		return s;
	char* res = (char*)malloc(sizeof(char) * (n + 1));
	for (int i = 0; i < round; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (j %(2*round-2) == i||j % (2*round-2)==2*round-2-i)
			{
				res[k++]=s[j];
			}
		}
	}
	res[k]='\0';
	return res;
}

int Input()
{
	int num = 0;
	int status = 0;
	char str[100];
	do
	{
		scanf("%s", str);
		status = 1;
		int i;
		for (i=0;str[i]!='\0';i++)
		{

			if (i == 0)
			{
				if (str[i]=='-'/*||str[i]=='+'*/)
				printf("����������������:");
					continue;
			}
			else
			{
				if (str[i] < '0' || str[i] > '9')
				{
					status = 0;
				}
			}
		}
		if (status == 0)
		{
			printf("����������������:");
		}
		else
		{
			 i = 0;
			for (i = 0, num = 0; str[i] != '\0'; i++)
			{
				if (i == 0)
				{
					if (str[i] == '-' || str[i] == '+')
					{
						continue;
					}
					else
					{
						num *= 10;
						num += (str[i] - 48);
					}
				}
				else
				{
					num *= 10;
					num += (str[i] - 48);
				}
			}
			if (str[0] == '-')
			{
				num = -num;
			}
			// Check if the number entered is out of bounds.
			if (i>=10)
			{
				printf("������Χ������������:");
				status = 0;
			}
		}
	} while (status == 0);
	return num;
}
