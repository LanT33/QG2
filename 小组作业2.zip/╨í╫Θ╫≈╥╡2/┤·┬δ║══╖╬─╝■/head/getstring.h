#ifndef GETSTRING_H_INCLUDED
#define GETSTRING_H_INCLUDED



#endif // GETSTRING_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
char* getstring(const char *str,int* m);
